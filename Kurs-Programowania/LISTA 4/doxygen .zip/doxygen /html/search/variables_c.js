var searchData=
[
  ['save_169',['save',['../classFrame.html#a59590f6a2d9bd9a06889196ff279d10e',1,'Frame']]],
  ['saveitem_170',['saveItem',['../classFrame.html#aacccf8e45ecca7fee419c327febf8459',1,'Frame']]],
  ['seecolor_171',['seeColor',['../classSurface.html#abb95baa721f85bed26075536fa81fcf4',1,'Surface']]],
  ['settingsmenu_172',['settingsMenu',['../classFrame.html#a85d92ecbf9cbaed5db3e6dbde0ba6c1f',1,'Frame']]],
  ['shape_173',['shape',['../classSurface.html#a546c3e463345823963ef770097188cfc',1,'Surface']]],
  ['shapemenu_174',['shapeMenu',['../classFrame.html#a2eed4a4d385eefb17c56bf2f5bd8551a',1,'Frame']]],
  ['shapes_175',['shapes',['../classSurface.html#ad98863e4cd79134705a9b6355e8565a0',1,'Surface']]],
  ['surface_176',['surface',['../classFrame.html#a337e9e8208ad3b9787c98e2f0b09addc',1,'Frame']]]
];
