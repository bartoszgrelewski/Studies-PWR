var searchData=
[
  ['load_37',['load',['../classFrame.html#ae5c3627fd02d371363393d760dccf12f',1,'Frame']]],
  ['loaditem_38',['loadItem',['../classFrame.html#a2cf7af48e2cb7c15839cc9ac11b18801',1,'Frame']]]
];
