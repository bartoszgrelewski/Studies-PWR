var searchData=
[
  ['triangle_80',['Triangle',['../classTriangle.html',1,'']]],
  ['triangleitem_81',['triangleItem',['../classFrame.html#a4666f0147d3c198340783bdafe96bd6c',1,'Frame']]],
  ['trojkat_82',['trojkat',['../classFrame.html#ad7672b45a1baca24c67a3c02b7ccfb4b',1,'Frame']]]
];
