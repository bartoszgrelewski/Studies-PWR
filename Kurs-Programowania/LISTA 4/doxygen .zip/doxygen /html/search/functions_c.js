var searchData=
[
  ['save_130',['save',['../classFrame.html#a60011b86594d8627d7b5f0aea36d588c',1,'Frame']]],
  ['setcolor_131',['setColor',['../interfaceShape.html#ab8601803653ba8cce7e129230186f4e6',1,'Shape.setColor()'],['../classCircle.html#a7a643b7f4e331dda353862765385d566',1,'Circle.setColor()'],['../classRectangle.html#a49490356ba8dbed31209c00fbf7ded41',1,'Rectangle.setColor()'],['../classTriangle.html#ab8995f3e51f8c3e5c639a348c93ff17b',1,'Triangle.setColor()']]],
  ['setx1_132',['setX1',['../interfaceShape.html#addd9576106450ef2e911879883867a03',1,'Shape.setX1()'],['../classCircle.html#a9660061d31bda087cc49e4da82cb7c44',1,'Circle.setX1()'],['../classRectangle.html#a3d8b0b05f91b65e8dc27dd5b176d7d94',1,'Rectangle.setX1()'],['../classTriangle.html#ae6ba97bd15cbd515f68118fe6819eda5',1,'Triangle.setX1()']]],
  ['setx2_133',['setX2',['../interfaceShape.html#af64d5da7b99d6ed603deb4e544399a82',1,'Shape.setX2()'],['../classCircle.html#aa1516b33dae1f90b8bb81e0e8a05da63',1,'Circle.setX2()'],['../classRectangle.html#a690e2b1e43f0b2ab5a2b1b143bab1f33',1,'Rectangle.setX2()'],['../classTriangle.html#a7a300faa8f14f6eb699b37bf4e3d61b7',1,'Triangle.setX2()']]],
  ['sety1_134',['setY1',['../interfaceShape.html#a928df2f2439b2b9802b6419ff28b4aeb',1,'Shape.setY1()'],['../classCircle.html#af0c12a841c3fbe8525b87cb2b94a1cf1',1,'Circle.setY1()'],['../classRectangle.html#af4cba91868ac40df62ee414ed2038f61',1,'Rectangle.setY1()'],['../classTriangle.html#a2692bc6ce4a6e741b30e899bf2bf8611',1,'Triangle.setY1()']]],
  ['sety2_135',['setY2',['../interfaceShape.html#aa3045c457249facb0541c10cfba17dd7',1,'Shape.setY2()'],['../classCircle.html#acb9c07dc079774289c4396f39252e2ee',1,'Circle.setY2()'],['../classRectangle.html#a9ddee3163e4caac39b5301808063edb3',1,'Rectangle.setY2()'],['../classTriangle.html#ae1320d59a3da61d6aea28e0d274e5622',1,'Triangle.setY2()']]],
  ['surface_136',['Surface',['../classSurface.html#a5368b25a8e8f41ecb00b960c940003e2',1,'Surface']]],
  ['surface_137',['surface',['../classFrame.html#aea646d9fb4da2ec42024239443bf905b',1,'Frame']]]
];
