var searchData=
[
  ['exit_105',['exit',['../classFrame.html#aade8e79e184ddefd1caceaa213d4bf7e',1,'Frame']]]
];
