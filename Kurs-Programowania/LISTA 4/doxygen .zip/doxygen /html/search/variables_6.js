var searchData=
[
  ['infoitem_159',['infoItem',['../classFrame.html#a339d13649be56495b922b8eb0cb33a7f',1,'Frame']]],
  ['infomenu_160',['infoMenu',['../classFrame.html#a312ecb3b276c2172d6d6c5b374626b8b',1,'Frame']]],
  ['instructionitem_161',['instructionItem',['../classFrame.html#a020138a9f603df26c2f0028b7a0aa05c',1,'Frame']]]
];
