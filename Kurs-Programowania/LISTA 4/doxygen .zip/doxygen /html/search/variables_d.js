var searchData=
[
  ['triangleitem_177',['triangleItem',['../classFrame.html#a4666f0147d3c198340783bdafe96bd6c',1,'Frame']]]
];
