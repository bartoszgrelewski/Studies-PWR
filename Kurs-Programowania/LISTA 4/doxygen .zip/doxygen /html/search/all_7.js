var searchData=
[
  ['info_32',['info',['../classFrame.html#acd21c71f5045df1263e667a051aadc82',1,'Frame']]],
  ['infoitem_33',['infoItem',['../classFrame.html#a339d13649be56495b922b8eb0cb33a7f',1,'Frame']]],
  ['infomenu_34',['infoMenu',['../classFrame.html#a312ecb3b276c2172d6d6c5b374626b8b',1,'Frame']]],
  ['instructionitem_35',['instructionItem',['../classFrame.html#a020138a9f603df26c2f0028b7a0aa05c',1,'Frame']]],
  ['instrukcja_36',['instrukcja',['../classFrame.html#ac136d5dd1a53deb54ba3d7827a4b8a5b',1,'Frame']]]
];
