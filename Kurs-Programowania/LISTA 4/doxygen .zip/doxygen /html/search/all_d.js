var searchData=
[
  ['rectangle_60',['Rectangle',['../classRectangle.html',1,'']]],
  ['rectangleitem_61',['rectangleItem',['../classFrame.html#ab7442650df57347a87ec85189534239c',1,'Frame']]],
  ['resize_62',['resize',['../interfaceShape.html#aa5d3868a9a79c4525f8b28e7f21925df',1,'Shape.resize()'],['../classCircle.html#abc5b33fcde20022b65011865c09931ec',1,'Circle.resize()'],['../classRectangle.html#a888e0fd2838ef078a395ef687097a84b',1,'Rectangle.resize()'],['../classTriangle.html#a3823808b1c248e45aa65c5bd65b9a379',1,'Triangle.resize()']]],
  ['returnval_63',['returnVal',['../classFrame.html#a561efeb0161029ce2e84dd3dbfc4f35a',1,'Frame']]]
];
