var searchData=
[
  ['file_157',['file',['../classFrame.html#afa824d0ac186b24449887fad5dc5acbd',1,'Frame']]],
  ['filechooser_158',['fileChooser',['../classFrame.html#a343779f8c5e1b6744917133edd045853',1,'Frame']]]
];
