var indexSectionsWithContent =
{
  0: "cdgmprst",
  1: "gmst",
  2: "gmst",
  3: "cdgmprs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions"
};

