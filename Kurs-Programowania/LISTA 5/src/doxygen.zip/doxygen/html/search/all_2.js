var searchData=
[
  ['getcolor_2',['getColor',['../class_square.html#a9fb79202af2b2b5c3e41f7055a7f355f',1,'Square']]],
  ['getneighbours_3',['getNeighbours',['../class_square.html#a8e4a0e098b6d86c734fa8227472dc87d',1,'Square']]],
  ['gui_4',['Gui',['../class_gui.html',1,'Gui'],['../class_gui.html#ac501c469ef61395a91b29c7aaf18da17',1,'Gui.Gui()']]],
  ['gui_2ejava_5',['Gui.java',['../_gui_8java.html',1,'']]]
];
