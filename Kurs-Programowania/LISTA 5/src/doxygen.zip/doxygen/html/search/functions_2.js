var searchData=
[
  ['getcolor_37',['getColor',['../class_square.html#a9fb79202af2b2b5c3e41f7055a7f355f',1,'Square']]],
  ['getneighbours_38',['getNeighbours',['../class_square.html#a8e4a0e098b6d86c734fa8227472dc87d',1,'Square']]],
  ['gui_39',['Gui',['../class_gui.html#ac501c469ef61395a91b29c7aaf18da17',1,'Gui']]]
];
