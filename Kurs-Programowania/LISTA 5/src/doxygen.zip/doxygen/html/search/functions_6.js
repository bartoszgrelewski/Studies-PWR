var searchData=
[
  ['setcolor_44',['setColor',['../class_square.html#a7a92abb49a8a70a72cdc36d5b8be2986',1,'Square']]],
  ['setneighbours_45',['setNeighbours',['../class_square.html#af31766c4ad08cfe7f4b4238dbaf9b936',1,'Square']]],
  ['stop_46',['stop',['../class_square.html#a82a04125f2d78909549b20d64f91e5aa',1,'Square']]]
];
