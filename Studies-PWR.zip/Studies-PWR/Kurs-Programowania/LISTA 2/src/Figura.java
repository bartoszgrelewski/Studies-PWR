abstract public class Figura implements policz {
}