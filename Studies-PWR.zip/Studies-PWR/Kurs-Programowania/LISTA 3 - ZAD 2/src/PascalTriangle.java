public class PascalTriangle {
    public static void main(String[] args) {
//GUI
        MyFrame myframe = new MyFrame();
    }
}
