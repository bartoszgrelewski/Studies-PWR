public interface policz {
    double pole();
    double obwod();
}
//roznica miedzy double a float jest taka,
//ze double wiecej miejsca zbiera i jest dokladniejszy