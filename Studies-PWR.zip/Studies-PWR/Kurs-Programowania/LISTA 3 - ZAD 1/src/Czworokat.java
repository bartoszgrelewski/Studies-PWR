abstract public class Czworokat extends Figura {
}