public class prosteGui {
    public static void main(String[] args) {
        Frame Gui = new Frame();
    }
}