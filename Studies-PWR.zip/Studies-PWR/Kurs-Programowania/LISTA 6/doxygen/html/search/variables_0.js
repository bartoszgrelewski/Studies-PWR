var searchData=
[
  ['data_50',['data',['../class_node.html#a0fda6f9f4d4f5fd1105f6df86c4ec4b8',1,'Node']]]
];
