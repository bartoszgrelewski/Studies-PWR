var searchData=
[
  ['main_10',['main',['../class_socket_client.html#a9892783d6efab9868a089ccdcfc78016',1,'SocketClient.main()'],['../class_socket_server.html#a997f8e3a9ba1df94a266167e985595d7',1,'SocketServer.main()']]]
];
