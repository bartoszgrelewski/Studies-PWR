var searchData=
[
  ['write_24',['write',['../class_gui.html#a8ce7a314176bff898dc18e9fdb07f4ce',1,'Gui.write()'],['../class_socket_server.html#a5cf0d5c08a7c373b5c37ff07f9897915',1,'SocketServer.write()']]]
];
