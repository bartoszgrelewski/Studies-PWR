var searchData=
[
  ['root_12',['root',['../class_tree.html#a1314ca9166f9a17f55d6512e2579a27f',1,'Tree']]]
];
