var searchData=
[
  ['delete_33',['delete',['../class_gui.html#a2be4e4cb3a3f2f994c8306c2ba433d5d',1,'Gui.delete()'],['../class_tree.html#a5d9f357727168659bee2357a5b137fe2',1,'Tree.delete()']]],
  ['deleteok_34',['deleteOk',['../class_gui.html#ae47547006c38c21c577a7396202b50b6',1,'Gui.deleteOk()'],['../class_socket_server.html#af013bba573b3b87d7ba0b4763656c4a8',1,'SocketServer.deleteOk()']]]
];
