var searchData=
[
  ['listensocket_9',['listenSocket',['../class_socket_client.html#a8102c224c984803778e8c45378f9ccd9',1,'SocketClient.listenSocket()'],['../class_socket_server.html#a19f512eaac5a8312d658168e907263cd',1,'SocketServer.listenSocket()']]]
];
