var searchData=
[
  ['search_43',['search',['../class_gui.html#a05e8607258296ffafe72c7013d447750',1,'Gui.search()'],['../class_tree.html#a03cedffcbe2d567b7624dd3fdf6cd26a',1,'Tree.search()']]],
  ['searchok_44',['searchOk',['../class_gui.html#a07309f8ff5904226dad6555bb0e4361b',1,'Gui.searchOk()'],['../class_socket_server.html#adcc35c66dd2b92f6d53d9f4aa8078480',1,'SocketServer.searchOk()']]],
  ['setdouble_45',['setDouble',['../class_gui.html#a1500e907012b81fdd15696b6a2630172',1,'Gui.setDouble()'],['../class_socket_server.html#a0e0311efabc9c808656a851fd8f50e90',1,'SocketServer.setDouble()']]],
  ['setinteger_46',['setInteger',['../class_gui.html#ac5395e610fb30d6c2b02b6c4a65c66d8',1,'Gui.setInteger()'],['../class_socket_server.html#af2efc911c267fd8f36fd2033634edaa1',1,'SocketServer.setInteger()']]],
  ['setstring_47',['setString',['../class_gui.html#a514db066d51e465632b0189a70d378a8',1,'Gui.setString()'],['../class_socket_server.html#aa5f37a1d4b07e6a963e20de6cd0c86b1',1,'SocketServer.setString()']]]
];
