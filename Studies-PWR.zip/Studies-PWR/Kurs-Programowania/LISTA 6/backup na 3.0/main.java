public class main {
    public static void main(String[] args) {
        Gui gui = new Gui();
        gui.setVisible(true);
    }
}
