var searchData=
[
  ['triangle_98',['Triangle',['../classTriangle.html',1,'']]]
];
