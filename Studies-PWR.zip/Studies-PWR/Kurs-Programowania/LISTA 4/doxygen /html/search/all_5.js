var searchData=
[
  ['file_24',['file',['../classFrame.html#afa824d0ac186b24449887fad5dc5acbd',1,'Frame']]],
  ['filechooser_25',['fileChooser',['../classFrame.html#a343779f8c5e1b6744917133edd045853',1,'Frame']]],
  ['frame_26',['Frame',['../classFrame.html',1,'Frame'],['../classFrame.html#af9ab032ec5dc0d010b1e5c4776677d6a',1,'Frame.Frame()']]]
];
