var searchData=
[
  ['b_1',['b',['../classCircle.html#afb50aa0e93593882b1cb4dc76ab15814',1,'Circle.b()'],['../classRectangle.html#ae37391a2ab19ff5dba76ff4bf0dbaed8',1,'Rectangle.b()'],['../classTriangle.html#af1d23a699d3a7073ad3c4c6e9390912b',1,'Triangle.b()']]],
  ['br_2',['br',['../classFrame.html#aa77ace80ce4d86ccb4d1433e2e84a3d1',1,'Frame']]]
];
