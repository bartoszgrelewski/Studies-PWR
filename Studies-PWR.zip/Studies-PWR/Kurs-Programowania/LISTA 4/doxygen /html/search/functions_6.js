var searchData=
[
  ['load_114',['load',['../classFrame.html#ae5c3627fd02d371363393d760dccf12f',1,'Frame']]]
];
