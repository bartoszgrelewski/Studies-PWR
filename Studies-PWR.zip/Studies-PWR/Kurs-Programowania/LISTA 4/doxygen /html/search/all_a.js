var searchData=
[
  ['nazwa_52',['nazwa',['../interfaceShape.html#a6fc68149373bb18b0fda5fa8ce8e8570',1,'Shape.nazwa()'],['../classCircle.html#ad39bf40411b26d34789a512b4eb357eb',1,'Circle.nazwa()'],['../classRectangle.html#aeb96e53682126da619f1edc47917229d',1,'Rectangle.nazwa()'],['../classTriangle.html#a10f8f00f5d9d45075d53079f46be408a',1,'Triangle.nazwa()']]]
];
