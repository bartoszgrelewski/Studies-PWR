var searchData=
[
  ['ok_124',['ok',['../classFrame.html#aeb17d8a197e9ae5e7ffad7007698ead5',1,'Frame']]],
  ['okrag_125',['okrag',['../classFrame.html#af714a9d5e3598d0b454fdd7031f8d3e5',1,'Frame']]]
];
