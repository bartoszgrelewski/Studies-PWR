var searchData=
[
  ['info_112',['info',['../classFrame.html#acd21c71f5045df1263e667a051aadc82',1,'Frame']]],
  ['instrukcja_113',['instrukcja',['../classFrame.html#ac136d5dd1a53deb54ba3d7827a4b8a5b',1,'Frame']]]
];
