var searchData=
[
  ['x_178',['x',['../classSurface.html#a86bc74bc71afd91684ab713200104cae',1,'Surface']]],
  ['x1_179',['x1',['../classCircle.html#ad1bc41f6124ad669eac2abde4014b185',1,'Circle.x1()'],['../classRectangle.html#a766bef2ada4f695f784981f2fce2f213',1,'Rectangle.x1()'],['../classTriangle.html#aed0ed0b992472c4e56b9237fe1870970',1,'Triangle.x1()']]],
  ['x2_180',['x2',['../classCircle.html#ad30be154c5d9819efc19982455d0df6a',1,'Circle.x2()'],['../classRectangle.html#a567d90d762fd4703bfa84f3df857b3a6',1,'Rectangle.x2()'],['../classTriangle.html#ad0b49e7f6fbafc32a4076178bcf98bf7',1,'Triangle.x2()']]]
];
